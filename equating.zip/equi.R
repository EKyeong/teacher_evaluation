
#  The Equivalent Groups (EG) Design is preferable . 

###### Using "equi" package ################
##### see, https://rdrr.io/github/twolodzko/equi/man/equi.html

install.packages("devtools")
library(devtools)
install_github("twolodzko/equi")

#############################

library(equi)

# Equivalent Groups design

form3.total<-read.csv(file = "x_freq.csv")
head(form3.total)
form3.total<-round(form3.total,digits = 0)
head(form3.total)

x<-form3.total["a"]
is.numeric(x)

x<-as.numeric(unlist(x))
x

y<-form3.total["b"]

y<-as.numeric(unlist(y))
y


eq <- equi(smoothtab(x), smoothtab(y))
eq
attributes(eq)
eq$concordance


yx <- equi(x, eq)
head(yx)

mean(x)
mean(y)

quantile(x, probs = seq(0.01, 0.99, by=0.01))

quantile(y, probs = seq(0.01, 0.99, by=0.01))


xy<-equi(y,eq)
head(xy)

#########

ct <- conttab(x, prob=TRUE)
ct
plot(ct, col="red", ylim=c(0, 0.20))


(ks <- kernsmooth(x))
plot(ks)
cdfplot(ks)

#####

ct.y<-conttab(y, prob=TRUE)
ct.y

(ks.y <- kernsmooth(y))
plot(ks.y)
cdfplot(ks.y)






