library(equate)

# Univariate distribution with score scale
set.seed(2005)
x <- round(rnorm(1000, 100, 10))
head(x)
head(freqtab(x, scales = 70:130))

sample<-read.csv(file = "x_freq.csv")
b<-round(sample, digits = 0)
b
freqtab(b)

### using 3 forms

library(equate)
sample3<-read.csv(file = "x_freq.csv")
head(sample3)
sample3.1<-round(sample3,digits = 0)
head(sample3.1)
a.x<-freqtab(sample3.1[,1])
a.x
head(a.x)

write.csv(a.x, file="ax.csv")

a.y<-freqtab(sample3.1[,2])
head(a.y)

a.z<-freqtab(sample3.1[,3])
head(a.z)

rbind(x = summary(a.x), y = summary(a.y),z = summary(a.z))


neat.ef <- equate(a.x, a.y,type = "equip",smooth="loglin",degree=3 )

neat.ef

attributes(neat.ef)
neat.ef$concordance

neat.ef$xsmooth


#  The Equivalent Groups (EG) Design is preferable . 


#######################
r1<-a.x
r2<-a.y
r3<-a.z

eqargs <- list(r1r2 = list(type = "linear", x = "r1", y = "r2",
                           name = " Linking PISA r3 to r5"),
               r2r3 = list(type = "linear", x = "r2", y = "r3",
                           name = "equip Linking PISA r5 to r6"))
               
req <- equate(list(r1 = r1, r2 = r2, r3 = r3), eqargs)

req

attributes(req)
req$r1r2$concordance


# Put PISA r3 on the scale of r7 using the linking chain
# Compare to a direct linking of r3 to r7
equate(equate(req$r1r2$conc$yx, req$r2r3))
equate(r1, r3, "equip")$conc$yx

equate(r1, r3, "equip")$conc

###### Using "equi" package ################
##### see, https://rdrr.io/github/twolodzko/equi/man/equi.html


install.packages("devtools")
library(devtools)
install_github("twolodzko/equi")

library(equi)

# Equivalent Groups design

data(Tests)
x <- Tests[Tests$Sample == "P", "x"]
y <- Tests[Tests$Sample == "P", "y"]


(eq <- equi(smoothtab(x), smoothtab(y)))
eq
attributes(eq)
eq$concordance


yx <- equi(x, eq)
head(yx)

###############

quantile(x, 0.75)
quantile(y, 0.75)
mean(x)
mean(y)

xy<-equi(y,eq)
head(xy)


###########

data(Tests)
x <- Tests[Tests$Sample == "P", "x"]

ct <- conttab(x, prob=TRUE)
ct
plot(ct, col="red", ylim=c(0, 0.13))

for (i in seq(.35, 2.5, by=.1))
  lines(kernsmooth(x, h=i, grid=1000)$data)

(ks <- kernsmooth(x))
plot(ks)
cdfplot(ks)






