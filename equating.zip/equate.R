
# Using "equate" program

library(equate)

form3.total<-read.csv(file = "x_freq.csv")
head(form3.total)
form3.total<-round(form3.total,digits = 0)
head(form3.total)

x<-freqtab(form3.total$a)
head(x)

y<-freqtab(form3.total$b)

z<-freqtab(form3.total$c)

# summary statistics

rbind(x = summary(x), y = summary(y),z = summary(z))

# Quantile for x,  y, and z

quantile(form3.total$a, probs = seq(0.01, 0.99, by=0.01))
quantile(form3.total$b, probs = seq(0.01, 0.99, by=0.01))

quantile(form3.total$c, probs = seq(0.01, 0.99, by=0.01))

# equipercentile equating using equate function for x and y

xy.per <- equate(x, y,type = "equip",smooth="loglin",degree=3 )

xy.per

# concordance table

attributes(xy.per)
xy.per$concordance

#### other CTT equating including mean and linear type

xy.mean <- equate(x, y,type = "mean" )
xy.mean$concordance
summary(xy.mean)


xy.lin <- equate(x, y,type = "lin" )
xy.lin$concordance
summary(xy.lin)

### Compare 3 equating method using plot

plot(xy.per,xy.mean,xy.lin, col = rep(rainbow(3),2), lty=rep(1:2, each=3), lwd=3)







